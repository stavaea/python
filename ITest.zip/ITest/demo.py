import time


print time.strftime('%Y-%m-%d_%H:%M:%S', time.localtime(time.time()))