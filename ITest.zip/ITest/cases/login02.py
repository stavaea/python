#coding:utf-8
import requests

from TestBase import TestBase

class Test(TestBase):

    def test_login02(self):
        url = 'http://139.199.132.220:8000/event/api/register/'
        data = {'username': 'huice', 'password': 'MTIzaHVpY2VodWljZQ=='}
        response = requests.post(url=url, data=data)
        error_code = response.json().get('error_code')
        self.assertEqual(error_code, 10000, '密码错误，状态码不正确')
        print u'系统管理员登录接口密码错误分支正确'