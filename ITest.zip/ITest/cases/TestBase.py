import unittest
import requests

class TestBase(unittest.TestCase):

    def setUp(self):
        url = 'http://139.199.132.220:8000/event/api/register/'
        data = {'username': 'huice', 'password': 'MTIzaHVpY2VodWljZSFAIw=='}
        response = requests.post(url=url, data=data)
        self.token = response.json().get('token')


