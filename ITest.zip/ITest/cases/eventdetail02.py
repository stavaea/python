#coding:utf-8
import requests
from TestBase import TestBase
class Test(TestBase):

    def test_eventdetail02(self):
        url = 'http://139.199.132.220:8000/event/api/get_eventdetail/'
        headers = {'token': self.token, 'random': '12345'}
        params = {'id': 3, 'username': 'huice', 'sign': '3285cffdeba75dc3572ec7dfc1bf7ed5'}
        response = requests.get(url=url, headers=headers, params=params)

        error_code = response.json().get('error_code')
        self.assertEqual(error_code, 10004, 'id不存在，响应状态码错误')
        print u'会议详细信息接口,会议id不存在异常分支正确'
