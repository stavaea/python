#coding:utf-8
import requests
from TestBase import TestBase

class Test(TestBase):
    '''登录接口'''
    def test_login01(self):
        '''登录正向流程'''
        url = 'http://139.199.132.220:8000/event/api/register/'
        data = {'username': 'huice', 'password': 'MTIzaHVpY2VodWljZSFAIw=='}
        response = requests.post(url=url, data=data)
        token = response.json().get('token')
        error_code = response.json().get('error_code')
        self.assertEqual(error_code, 0, '错误码不为0')
        self.assertNotEqual(token, None, 'token不存在')
        print u'系统管理员登录接口正向流程正确'



