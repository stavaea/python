#coding:utf-8
from django.db import models

# Create your models here.

class User(models.Model):
    name = models.CharField(max_length=20)
    pwd = models.CharField(max_length=20)

class Author(models.Model):
    name = models.CharField(max_length=30)
    def __unicode__(self):
        return self.name

    class Meta:
        verbose_name = '作者表'
        verbose_name_plural = verbose_name

class AuthorDetails(models.Model):
    age = models.IntegerField()
    email = models.CharField(max_length=50)
    sex = models.IntegerField(choices=((0, '男'), (1, '女')))
    phone = models.CharField(max_length=15)
    author = models.OneToOneField(Author)

class Publisher(models.Model):
    name = models.CharField(max_length=30)
    address = models.CharField(max_length=50)
    city = models.CharField(max_length=30)
    website = models.URLField()

class Book(models.Model):
    title = models.CharField(max_length=100)
    publication_date = models.DateField()
    pulisher = models.ForeignKey(Publisher)
    author = models.ManyToManyField(Author)

