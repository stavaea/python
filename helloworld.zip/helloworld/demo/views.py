#coding:utf-8
from django.shortcuts import render,render_to_response
from django.http import HttpResponse,JsonResponse
import csv,os
import json
from django.contrib import auth
# Create your views here.
from models import *

def index(request):
    # author = Author.objects.get(name='李黑')
    # author = Author.objects.filter(name='李白').delete()
    User.objects.create(name='zhangsan', pwd='12345')
    return HttpResponse('1')
    # username = request.COOKIES.get('username')
    # password = request.COOKIES.get('password')
    # if username and password:
    #
    #     return render(request, 'home.html', {'info':u'欢迎登录：%s' % username})
    # else:
    #     return render(request, 'login.html')



def home(request):
    if request.method == 'GET':
        username = request.GET.get('username')
        pwd = request.GET.get('password')

        if username and pwd:
            return render(request, 'home.html', {'info':u'欢迎登录：%s' % username})
        else:
            return render(request, 'error.html', {'info': u'用户名或密码为空'})
    else:
        return render(request, 'error.html', {'info':u'请求类型错误'})

def bugs(request):
    month = request.GET.get('month', None)
    if month:
        try:
            month = int(month)
            if month in range(1, 10):
                month = '2016_0'+str(month)
                sum = search_by_month(month)
                # info = u'%s 月，bug总数为：%d' % (month, sum)
                dic = {'month':month, 'total':sum}
                json.dumps(dic)
                return HttpResponse(content="{'month':'%s', 'total':%d}"%(month, sum), content_type='application/json')
            elif month in range(10, 13):
                month = '2016_' + str(month)
                sum = search_by_month(month)
                # info = u'%s 月，bug总数为：%d' % (month, sum)
                # return JsonResponse("{'month':'%s', 'total':%d}" % (month, sum))
                return HttpResponse(content="{'month':'%s', 'total':%d}" % (month, sum), content_type='application/json')
            else:
                info = u'month参数无效'
        except:
            info = u'month参数无效'
    else:
        info = u'month为必填参数'
    return HttpResponse(content="{'info':%s}"%info, content_type='application/json')
    # return render(request, 'home.html', {'info':info})

def search_by_month(month):
    data = {
        "business_autoFans_J": [{"2016_08": 14}, {"2016_09": 15}, {"2016_10": 9}],
        "autoAX": [{"2016_08": 7}, {"2016_09": 32}, {"2016_10": 0}],
        "autoAX_admin": [{"2016_08": 5}, {"2016_09": 13}, {"2016_10": 2}],
    }
    sum = 0
    for v in data.values():
        for d in v:
            if d.has_key(month):
                sum = sum + d.get(month, 0)
    return sum


def search_user(username, pwd):
    file_name = './data.csv'
    flag = False
    try:
        with open(file_name) as f:
            data = csv.reader(f)
            for d in list(data):
                if d[0] == username and d[1] == pwd:
                    flag = True
    except Exception as e:
        print e.message
    return flag

def login(request):
    http_response = HttpResponse()
    issave = request.POST.get('isSave')
    if request.method == 'POST':
        username = request.POST.get('username', None)
        password = request.POST.get('password', None)
        if username and password:
            if len(username) > 5:
                # user = search_user(username, password)
                # user = auth.authenticate(username=username, password=password)
                try:
                    user = User.objects.get(name=username, pwd=password)
                except:
                    user = None
                if user:
                    if issave:
                        http_response.set_cookie('username', username, max_age=10)
                        http_response.set_signed_cookie('password', password, salt='123', max_age=10)
                    info = u'欢迎登录：%s' % username
                else:
                    info = u'用户名或密码错误'
            else:
                info = u'用户名不能小于5位'
        else:
            info = u'用户名或密码为空'
    else:
        info = u'请求类型无效'
    http_response.content = info
    return render(request, 'home.html', {'info':info})
