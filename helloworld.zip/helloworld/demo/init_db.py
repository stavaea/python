#coding:utf-8
import os,django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "helloworld.settings")
django.setup()
from demo.models import *
import xlrd


book = xlrd.open_workbook(u'./图书信息表.xls')
table = book.sheet_by_name(u'作者信息')
names = table.col_values(0)
print len(names)
for i in range(1, len(names)):
    Author(name=names[i]).save()