#coding:utf-8
import json


dict = {'1':'张三'}
print json.dumps(dict, ensure_ascii=False)
