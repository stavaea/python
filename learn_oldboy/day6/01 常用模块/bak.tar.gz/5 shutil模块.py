import shutil

shutil.make_archive("bak", 'gztar', root_dir=r'F:\Python周末20期\day6') #tar cvzf bak.tar.gz /root