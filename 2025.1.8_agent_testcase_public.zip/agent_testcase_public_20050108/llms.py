from pydantic_ai.models.openai import OpenAIModel
model = OpenAIModel(model_name="deepseek-chat",
                    api_key="sk-a09a39f82c274c7688d6abf1beec3215",
                    base_url="https://api.deepseek.com/v1")
